---------------------------------------------------------------------------
-- PreflightTest Widget
-- EdgeTX 2.11.4
-- Background color hardcoded to BLACK
---------------------------------------------------------------------------

local name = "preflightTest"

-- sound state
local soundPlayed = false

-- recovery clear delay (9 seconds)
local RECOVERY_CLEAR_TICKS = 9 * 100

-- Lua-only timers for recovered state
local recoveryTime = {}

---------------------------------------------------------------------------
-- CREATE
---------------------------------------------------------------------------

local function create(zone, options)
  return {
    zone = zone,
    options = options or {}
  }
end

---------------------------------------------------------------------------
-- UPDATE
---------------------------------------------------------------------------

local function update(widget, options)
  widget.options = options
end

---------------------------------------------------------------------------
-- REFRESH
---------------------------------------------------------------------------

local function refresh(widget, event, touchState)
  local z = widget.zone
  local o = widget.options or {}

  -- Background (hardcoded to black)
  --lcd.drawFilledRectangle(z.x, z.y, z.w, z.h,COLOR_BLACK)

  -------------------------------------------------------------------------
  -- Feature enables (GV8 / GV9 master switch via FM0)
  -------------------------------------------------------------------------
  local gv9Enabled = (model.getGlobalVariable(8, 0) == 1024)
  local gv8Enabled = (model.getGlobalVariable(7, 0) == 1024)

  -- Title
  lcd.drawText(
    z.x + z.w / 2,
    z.y + 8,
    "PREFLIGHT CHECK",
    DBLSIZE + CENTER + WHITE
  )

  -- ADV / ADV+ indicator (top-right)
  if gv8Enabled or gv9Enabled then
    local advText
    local advColor

    if gv8Enabled and gv9Enabled then
      advText  = "ADV+"
      advColor = GREEN
    else
      advText  = "ADV"
      advColor = YELLOW
    end

    lcd.drawText(
      z.x + z.w - 10,
      z.y + 10,
      advText,
      RIGHT + advColor
    )
  end

  local y = z.y + 65
  local anyFail = false
  local anyUsed = false

  -- counters
  local passedCount = 0
  local failedCount = 0

  -- Slower flashing FAIL (~0.33 Hz)
  local blinkFail = (getTime() % 60) < 30

  -- Flashing "Previous Failure" (~0.25 Hz)
  local blinkPrev = (getTime() % 80) < 40

  -------------------------------------------------------------------------
  -- Draw one switch row
  -------------------------------------------------------------------------
  local function drawRow(label, source, rowIndex)
    if source and source ~= 0 then
      anyUsed = true

      local active = getValue(source) > 0
      local statusText
      local statusFlag

      -- GV9 failure history uses FM4..FM8
      local gvIndex = rowIndex + 3
      local gv = gv9Enabled and model.getGlobalVariable(8, gvIndex) or 0

      -- GV8 advisory enable FM4..FM8
      local advisoryGV = gv8Enabled and model.getGlobalVariable(7, gvIndex) or 0
      local isAdvisory = (advisoryGV == 1024)

      ---------------------------------------------------------------------
      -- State machine
      -- 0 = clean
      -- 1 = fail
      -- 2 = recovered
      ---------------------------------------------------------------------
      if active then
        if isAdvisory then
          -- ADVISORY (non-fatal)
          statusText = "ADVISORY"
          statusFlag = YELLOW
          passedCount = passedCount + 1
        else
          -- FAIL
          statusText = "FAIL"
          statusFlag = RED
          anyFail = true
          failedCount = failedCount + 1

          if gv9Enabled and gv ~= 1 then
            model.setGlobalVariable(8, gvIndex, 1)
            gv = 1
          end

          recoveryTime[rowIndex] = nil
        end
      else
        -- PASS
        statusText = "PASS"
        statusFlag = GREEN
        passedCount = passedCount + 1

        if gv9Enabled then
          if gv == 1 then
            model.setGlobalVariable(8, gvIndex, 2)
            gv = 2
            recoveryTime[rowIndex] = getTime()

          elseif gv == 2 then
            if recoveryTime[rowIndex] then
              if (getTime() - recoveryTime[rowIndex]) > RECOVERY_CLEAR_TICKS then
                model.setGlobalVariable(8, gvIndex, 0)
                gv = 0
                recoveryTime[rowIndex] = nil
              end
            end
          end
        end
      end

      lcd.drawText(z.x + 20, y, label, WHITE)

      local statusX = z.x + z.w - 20

      -- Flashing FAIL text only for real failures
      if statusText ~= "FAIL" or blinkFail then
        lcd.drawText(
          statusX,
          y,
          statusText,
          RIGHT + statusFlag
        )
      end

      -- Previous Failure indicator (PASS only, state = 2)
      if gv9Enabled and (not active) and gv == 2 and blinkPrev then
        lcd.drawText(
          statusX - 160,
          y,
          "Previous Failure",
          RED
        )
      end

      y = y + 26

      lcd.drawFilledRectangle(
        z.x + 20,
        y,
        z.w - 40,
        1,
        GREY
      )

      y = y + 6
    end
  end

  -------------------------------------------------------------------------
  -- Switch rows (5 switches, 5 labels)
  -------------------------------------------------------------------------
  drawRow(o.lbl1 or "SW1", o.sw1, 1)
  drawRow(o.lbl2 or "SW2", o.sw2, 2)
  drawRow(o.lbl3 or "SW3", o.sw3, 3)
  drawRow(o.lbl4 or "SW4", o.sw4, 4)
  drawRow(o.lbl5 or "SW5", o.sw5, 5)

  -------------------------------------------------------------------------
  -- FINAL STATUS
  -------------------------------------------------------------------------
  local resultText
  local resultFlag

  if not anyUsed then
    resultText = "NO CHECKS CONFIGURED"
    resultFlag = WHITE
  elseif anyFail then
    resultText = "CHECKS FAILED"
    resultFlag = RED
  else
    resultText = "CHECKS PASSED"
    resultFlag = GREEN
  end

 --------------------------------------------------------------------------
 -- Voice alert on failure (play once per failure state)
 --------------------------------------------------------------------------

  if anyFail and not soundPlayed then
    playFile("/SOUNDS/en/SYSTEM/pfcf.wav")
    soundPlayed = true
  elseif not anyFail then
    soundPlayed = false
  end
 --------------------------------------------------------------------------

  local baseY = z.y + z.h - 30

  -- FINAL STATUS label (always white)
  lcd.drawText(
    z.x + 10,
    baseY,
    "FINAL STATUS:",
    WHITE
  )

  -- FINAL STATUS result (colored)
  lcd.drawText(
    z.x + 125,
    baseY,
    resultText,
    resultFlag
  )

  -- Progress indicator (right side)
  if anyUsed then
    lcd.drawText(
      z.x + z.w - 10,
      baseY,
      failedCount .. " Failed / " .. passedCount .. " Passed",
      RIGHT + WHITE
    )
  end
end

---------------------------------------------------------------------------
-- OPTIONS (5 switches + 5 labels)
---------------------------------------------------------------------------

local options = {
  { "sw1",  SOURCE, nil },
  { "lbl1", STRING, "SW1" },

  { "sw2",  SOURCE, nil },
  { "lbl2", STRING, "SW2" },

  { "sw3",  SOURCE, nil },
  { "lbl3", STRING, "SW3" },

  { "sw4",  SOURCE, nil },
  { "lbl4", STRING, "SW4" },

  { "sw5",  SOURCE, nil },
  { "lbl5", STRING, "SW5" },
}

---------------------------------------------------------------------------
-- RETURN
---------------------------------------------------------------------------

return {
  name = name,
  create = create,
  refresh = refresh,
  update = update,
  options = options
}
